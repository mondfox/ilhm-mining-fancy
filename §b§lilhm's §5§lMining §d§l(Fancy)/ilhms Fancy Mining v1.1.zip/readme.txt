ilhm's Mining Pack ----------------------------------------------------------------
https://mondfox.github.io/ilhmminingpack/ to customize pack
SOUNDS ----------------------------------------------------------------------------

removing custom sounds
=============================
first off fuck you dont do this its way better

delete assets\minecraft\sounds\mob if you want to get rid of etherwarp sound

delete assets\minecraft\sounds\random if you want to get rid of glass sound

sources for sounds
=============================
gemstone sound is from elodurs(?) gemstone pack, i just repitched so its not always the same noise

etherwarp is from some tibetan singing bowl yt vid and heavily modified, if you want link its in metadata of the sound. if its not then its bc you cant do that. i didnt check.

TEXTURES --------------------------------------------------------------------------

removing textures
=============================
delete everything named "glass_(color).png) from the "assets\minecraft\textures\blocks" folder to get rid of glass smooth textures

delete cobblestone.png from the "assets\minecraft\textures\blocks" folder to get rid of cobblestone texture, same with bedrock/sandstone

delete "glass_pane_edges.png" and "glass_pane_sides.png" from the "assets\minecraft\textures\blocks" folder, along with the "assets\minecraft\models" folder to remove the custom glass panes

you can also modify "glass_pane_edges.png" and "glass_pane_sides.png" to change texture of glass panes (separate from glass blocks texture)

sources for textures
=============================
gems are elodurs GEMS ARE EOLOLODURS PLS DONT GET MAD THAT I USED THEM NOONE WILL EVER USE THIS PACK <3
bedrock is https://static.planetminecraft.com/files/image/minecraft/texture-pack/2021/230/13996138-newpiskel_m.jpg
cobble is downscaled https://minecraft.novaskin.me/skin/1749563165/


COMING SQQN/I NEED HELP -----------------------------------------------------------

contact me on discord @dogfucker2

will make a version with textures that arent ugly as fuck
hey thats this version

enjoy the pack :3